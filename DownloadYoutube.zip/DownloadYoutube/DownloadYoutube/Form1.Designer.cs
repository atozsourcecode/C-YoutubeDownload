﻿namespace DownloadYoutube
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btDownload = new System.Windows.Forms.Button();
            this.workProgress = new System.Windows.Forms.ProgressBar();
            this.tbURL = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btGetVideoDetail = new System.Windows.Forms.Button();
            this.dgvData = new System.Windows.Forms.DataGridView();
            this.URL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Download = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.VideoName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Resolution = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Type = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Size = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Decrypt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lDownloadStatus = new System.Windows.Forms.Label();
            this.lDownloadBytes = new System.Windows.Forms.Label();
            this.tbSaveFolder = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvData)).BeginInit();
            this.SuspendLayout();
            // 
            // btDownload
            // 
            this.btDownload.Location = new System.Drawing.Point(508, 454);
            this.btDownload.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btDownload.Name = "btDownload";
            this.btDownload.Size = new System.Drawing.Size(100, 33);
            this.btDownload.TabIndex = 0;
            this.btDownload.Text = "Download";
            this.btDownload.UseVisualStyleBackColor = true;
            this.btDownload.Click += new System.EventHandler(this.btDownload_Click);
            // 
            // workProgress
            // 
            this.workProgress.Location = new System.Drawing.Point(13, 454);
            this.workProgress.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.workProgress.Name = "workProgress";
            this.workProgress.Size = new System.Drawing.Size(487, 33);
            this.workProgress.TabIndex = 1;
            // 
            // tbURL
            // 
            this.tbURL.Location = new System.Drawing.Point(13, 33);
            this.tbURL.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbURL.Name = "tbURL";
            this.tbURL.Size = new System.Drawing.Size(434, 27);
            this.tbURL.TabIndex = 2;
            this.tbURL.Text = "https://www.youtube.com/watch?v=ZbJy4XsRL_8";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 19);
            this.label1.TabIndex = 3;
            this.label1.Text = "Youtube URL";
            // 
            // btGetVideoDetail
            // 
            this.btGetVideoDetail.Location = new System.Drawing.Point(13, 70);
            this.btGetVideoDetail.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btGetVideoDetail.Name = "btGetVideoDetail";
            this.btGetVideoDetail.Size = new System.Drawing.Size(100, 33);
            this.btGetVideoDetail.TabIndex = 4;
            this.btGetVideoDetail.Text = "Video Detail";
            this.btGetVideoDetail.UseVisualStyleBackColor = true;
            this.btGetVideoDetail.Click += new System.EventHandler(this.btGetVideoDetail_Click);
            // 
            // dgvData
            // 
            this.dgvData.AllowUserToAddRows = false;
            this.dgvData.AllowUserToDeleteRows = false;
            this.dgvData.AllowUserToResizeColumns = false;
            this.dgvData.AllowUserToResizeRows = false;
            this.dgvData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvData.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.URL,
            this.Download,
            this.VideoName,
            this.Resolution,
            this.Type,
            this.Size,
            this.Decrypt});
            this.dgvData.Location = new System.Drawing.Point(13, 111);
            this.dgvData.Name = "dgvData";
            this.dgvData.RowHeadersVisible = false;
            this.dgvData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvData.Size = new System.Drawing.Size(596, 335);
            this.dgvData.TabIndex = 5;
            // 
            // URL
            // 
            this.URL.DataPropertyName = "URL";
            this.URL.HeaderText = "URL";
            this.URL.Name = "URL";
            this.URL.Visible = false;
            // 
            // Download
            // 
            this.Download.HeaderText = "Download";
            this.Download.Name = "Download";
            // 
            // VideoName
            // 
            this.VideoName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.VideoName.DataPropertyName = "VideoName";
            this.VideoName.HeaderText = "Video Name";
            this.VideoName.Name = "VideoName";
            this.VideoName.ReadOnly = true;
            // 
            // Resolution
            // 
            this.Resolution.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Resolution.DataPropertyName = "Resolution";
            this.Resolution.HeaderText = "Resolution";
            this.Resolution.Name = "Resolution";
            this.Resolution.ReadOnly = true;
            this.Resolution.Width = 103;
            // 
            // Type
            // 
            this.Type.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Type.DataPropertyName = "Type";
            this.Type.HeaderText = "Type";
            this.Type.Name = "Type";
            this.Type.ReadOnly = true;
            this.Type.Width = 64;
            // 
            // Size
            // 
            this.Size.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.Size.DataPropertyName = "Size";
            this.Size.HeaderText = "Size";
            this.Size.Name = "Size";
            this.Size.ReadOnly = true;
            this.Size.Width = 59;
            // 
            // Decrypt
            // 
            this.Decrypt.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Decrypt.DataPropertyName = "Decrypt";
            this.Decrypt.HeaderText = "Decrypt";
            this.Decrypt.Name = "Decrypt";
            this.Decrypt.Width = 84;
            // 
            // lDownloadStatus
            // 
            this.lDownloadStatus.AutoSize = true;
            this.lDownloadStatus.Location = new System.Drawing.Point(120, 77);
            this.lDownloadStatus.Name = "lDownloadStatus";
            this.lDownloadStatus.Size = new System.Drawing.Size(59, 19);
            this.lDownloadStatus.TabIndex = 6;
            this.lDownloadStatus.Text = "[Status]";
            // 
            // lDownloadBytes
            // 
            this.lDownloadBytes.AutoSize = true;
            this.lDownloadBytes.Location = new System.Drawing.Point(483, 77);
            this.lDownloadBytes.Name = "lDownloadBytes";
            this.lDownloadBytes.Size = new System.Drawing.Size(84, 19);
            this.lDownloadBytes.TabIndex = 7;
            this.lDownloadBytes.Text = "[Download]";
            // 
            // tbSaveFolder
            // 
            this.tbSaveFolder.Location = new System.Drawing.Point(455, 33);
            this.tbSaveFolder.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbSaveFolder.Name = "tbSaveFolder";
            this.tbSaveFolder.Size = new System.Drawing.Size(154, 27);
            this.tbSaveFolder.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(451, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 19);
            this.label2.TabIndex = 9;
            this.label2.Text = "Folder Name";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(621, 497);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbSaveFolder);
            this.Controls.Add(this.lDownloadBytes);
            this.Controls.Add(this.lDownloadStatus);
            this.Controls.Add(this.dgvData);
            this.Controls.Add(this.btGetVideoDetail);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbURL);
            this.Controls.Add(this.workProgress);
            this.Controls.Add(this.btDownload);
            this.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.dgvData)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btDownload;
        private System.Windows.Forms.ProgressBar workProgress;
        private System.Windows.Forms.TextBox tbURL;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btGetVideoDetail;
        private System.Windows.Forms.DataGridView dgvData;
        private System.Windows.Forms.DataGridViewTextBoxColumn URL;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Download;
        private System.Windows.Forms.DataGridViewTextBoxColumn VideoName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Resolution;
        private System.Windows.Forms.DataGridViewTextBoxColumn Type;
        private System.Windows.Forms.DataGridViewTextBoxColumn Size;
        private System.Windows.Forms.DataGridViewTextBoxColumn Decrypt;
        private System.Windows.Forms.Label lDownloadStatus;
        private System.Windows.Forms.Label lDownloadBytes;
        private System.Windows.Forms.TextBox tbSaveFolder;
        private System.Windows.Forms.Label label2;
    }
}

