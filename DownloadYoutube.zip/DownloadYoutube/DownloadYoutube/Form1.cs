﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using YoutubeExtractor;

namespace DownloadYoutube
{
    public partial class Form1 : Form
    {
        IEnumerable<VideoInfo> videoInfos = null;
        BackgroundWorker m_oWorker;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            m_oWorker = new BackgroundWorker();

            m_oWorker.DoWork += M_oWorker_DoWork;
            m_oWorker.WorkerReportsProgress = true;
            m_oWorker.WorkerSupportsCancellation = true;
        }

        private void btGetVideoDetail_Click(object sender, EventArgs e)
        {
            try
            {
                dgvData.Rows.Clear();

                videoInfos = DownloadUrlResolver.GetDownloadUrls(tbURL.Text, false).OrderBy(c => c.Resolution).ToList();

                foreach (var item in videoInfos)
                {
                    if (item.Resolution > 0 && item.AudioBitrate > 0)
                    {
                        dgvData.Rows.Add(item.DownloadUrl, false, item.Title, item.Resolution, item.VideoType, 0, item.RequiresDecryption);
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show("Try Again.");
            }
        }

        private void M_oWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            DownloadVideo();
        }

        private void btDownload_Click(object sender, EventArgs e)
        {
            m_oWorker.RunWorkerAsync();
        }

        private void VideoDownloader_DownloadFinished(object sender, EventArgs e)
        {
            RefreshText(lDownloadStatus, "Download Complete");
            tbURL.Text = string.Empty;
        }

        private void VideoDownloader_DownloadStarted(object sender, EventArgs e)
        {
            RefreshText(lDownloadStatus, "Downloading...");
        }

        private void VideoDownloader_DownloadProgressChanged(object sender, ProgressEventArgs e)
        {
            RefreshText(lDownloadBytes, e.DownloadBytes);

            ProgressBarValueChange(0, (int)e.ProgressPercentage);
        }

        private static string RemoveIllegalPathCharacters(string path)
        {
            string regexSearch = new string(Path.GetInvalidFileNameChars()) + new string(Path.GetInvalidPathChars());
            var r = new Regex(string.Format("[{0}]", Regex.Escape(regexSearch)));
            return r.Replace(path, "");
        }

        private void DownloadVideo()
        {
            ProgressBarValueChange(100, 0);

            foreach (DataGridViewRow item in dgvData.Rows)
            {
                bool IsDownload = (bool)item.Cells["Download"].Value;
                VideoType _VideoType = (VideoType)item.Cells["Type"].Value;
                Int32 _Resolution = (Int32)item.Cells["Resolution"].Value;

                if (IsDownload)
                {
                    VideoInfo video = videoInfos.First(info => info.VideoType == _VideoType && info.Resolution == _Resolution);

                    if (video.RequiresDecryption)
                    {
                        DownloadUrlResolver.DecryptDownloadUrl(video);
                    }

                    string SaveFilePath = Application.StartupPath + "\\" + tbSaveFolder.Text + "\\";

                    if (!Directory.Exists(SaveFilePath))
                        Directory.CreateDirectory(SaveFilePath);

                    var videoDownloader = new VideoDownloader(video, Path.Combine(SaveFilePath, RemoveIllegalPathCharacters(video.Title) + video.VideoExtension));
                    videoDownloader.DownloadProgressChanged += VideoDownloader_DownloadProgressChanged;
                    videoDownloader.DownloadStarted += VideoDownloader_DownloadStarted;
                    videoDownloader.DownloadFinished += VideoDownloader_DownloadFinished;
                    videoDownloader.Execute();
                }
            }
        }

        public void RefreshText(Control ctrl, string Text)
        {
            try
            {
                ctrl.Invoke((Action)delegate ()
                {
                    ctrl.Text = Text;
                    ctrl.Refresh();
                });
            }
            catch
            {
                ctrl.Dispose();
            }
        }

        public void ProgressBarValueChange(Int32 MaxLength, Int32 Value)
        {
            try
            {
                if (MaxLength > 0)
                {
                    workProgress.Invoke((Action)delegate ()
                    {
                        workProgress.Maximum = MaxLength;
                        workProgress.Refresh();
                    });
                }
                else
                {
                    workProgress.Invoke((Action)delegate ()
                    {
                        workProgress.Value = Value;
                        workProgress.Refresh();
                    });
                }
            }
            catch
            {
                workProgress.Dispose();
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) this.Close();
        }
    }
}
